document.getElementById('revealBtn').addEventListener('click', () => {
  document.getElementById('hiddenScroll').classList.toggle('hidden');
});
